from .showquota import main
from .config import __version__, __author__, __license__
name = "showquota"

__all__ = ['__version__', '__author__', '__license__', 'main']
