__version__ = '1.0.1'
__author__  = 'Giulio Librando <giuliolibrando@gmail.com>'
__license__ = 'MIT'
